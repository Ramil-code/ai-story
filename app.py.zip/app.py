import json
import os
import re
import boto3

# Initialize AWS clients
bedrock_client = boto3.client("bedrock-runtime", region_name="us-east-1")
s3_client = boto3.client("s3")
polly_client = boto3.client("polly")

# Approximate speech speed (words per minute)
WORDS_PER_MINUTE = 160

def lambda_handler(event, context):
    try:
        # 1. Read input data
        body = json.loads(event.get("body", "{}"))
        prompt_text = body.get("prompt", "Write a short text for narration.")
        desired_duration = int(body.get("desiredDuration", 30))  # in seconds

        # 1a. Calculate the desired number of words and define max_new_tokens
        desired_words = (desired_duration / 60) * WORDS_PER_MINUTE
        max_new_tokens = int(desired_words * 1.2)  # Adding a small buffer

        print(f"DEBUG: desired_duration={desired_duration}s, desired_words={desired_words:.2f}, max_new_tokens={max_new_tokens}")

        # 2. Prepare request payload for Bedrock (amazon.nova-micro)
        request_payload = {
            "inferenceConfig": {
                "max_new_tokens": max_new_tokens
            },
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "text": prompt_text
                        }
                    ]
                }
            ]
        }

        # 2a. Invoke model "amazon.nova-micro-v1:0" via Bedrock Runtime
        response = bedrock_client.invoke_model(
            modelId="amazon.nova-micro-v1:0",
            accept="application/json",
            contentType="application/json",
            body=json.dumps(request_payload)
        )

        # 2b. Read and parse response
        response_body = response["body"].read()
        response_json = json.loads(response_body)
        print("DEBUG Bedrock response:", response_json)

        # 2c. Extract generated text
        generated_text = response_json.get("output", {}).get("message", {}).get("content", [{}])[0].get("text", "").strip()

        if not generated_text:
            raise ValueError("Bedrock response does not contain the expected text field.")

        # 3. Estimate approximate duration
        word_count = len(re.findall(r"\w+", generated_text))
        estimated_time_sec = (word_count / WORDS_PER_MINUTE) * 60

        final_text = generated_text

        # Adjust text length based on duration
        if estimated_time_sec > desired_duration * 1.2:
            max_words = int((desired_duration / 60) * WORDS_PER_MINUTE)
            words_list = re.findall(r"\S+", generated_text)
            final_text = " ".join(words_list[:max_words])

        # 4. Generate audio file without SSML
        polly_response = polly_client.synthesize_speech(
            Text=final_text,
            TextType="text",  # Using plain text
            VoiceId="Kendra", 
            OutputFormat="mp3"
        )

        if "AudioStream" not in polly_response:
            raise ValueError("Polly did not return audio data.")

        audio_stream = polly_response["AudioStream"].read()

        # 5. Save generated MP3 file to S3
        s3_bucket_name = "REPLACE"  # Specify your S3 bucket
        s3_key = f"polly-audio-{context.aws_request_id}.mp3"

        s3_client.put_object(
            Bucket=s3_bucket_name,
            Key=s3_key,
            Body=audio_stream,
            ContentType="audio/mpeg",
        )

        # 6. Generate public URL for S3 object
        public_url = f"https://{s3_bucket_name}.s3.us-east-2.amazonaws.com/{s3_key}"
        print(f"DEBUG: Public audio URL - {public_url}")

        # 7. Prepare response for the client
        response_body_final = {
            "text": final_text,
            "estimatedTimeSec": estimated_time_sec,
            "audioUrl": public_url
        }

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response_body_final)
        }

    except Exception as e:
        print(f"Error in Lambda: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": str(e)}, ensure_ascii=False)
        }
